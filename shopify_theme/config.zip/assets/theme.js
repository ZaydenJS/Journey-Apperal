/* Theme JS stub to avoid 404s and host any small enhancements. */
(function(){
  // Placeholder for future enhancements (e.g., menu toggle hooks)
})();

