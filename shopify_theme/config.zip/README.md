# Journeys Apparel Shopify Theme (OS 2.0)

This theme converts the existing static site design into a Shopify theme while preserving the visual layout. It relies on your original CSS for pixel-accurate styling and uses Shopify Liquid for products, collections, cart, and checkout.

## Structure

- layout/theme.liquid
  - Loads Shopify header assets (`{{ content_for_header }}`)
  - Loads your original CSS from journeysapparel.com for identical visuals
  - Renders header/footer sections around `{{ content_for_layout }}`
- sections/
  - header.liquid: Header + nav links
  - footer.liquid: Footer layout + newsletter form
  - hero.liquid: Home hero with background video
  - featured-collection.liquid: Configurable collection carousel/grid
- snippets/
  - product-card.liquid: Product tile used across lists
- templates/
  - index.liquid: Home; includes `hero` and two `featured-collection` sections (select collections in customizer)
  - collection.liquid: Collection grid with pagination
  - product.liquid: Product page with image gallery and product form
  - page.liquid: Generic content page
  - cart.liquid: Cart page with native checkout button

## Preserving Your Visual Design

- The theme loads `https://journeysapparel.com/styles.css` directly so layout, typography, spacing, and component classes match the static site.
- You can add small adjustments via `assets/theme.css` (optional). Remove or replace the external CSS when you’re ready to migrate styles locally.

## Using In Shopify

1. Zip upload
   - Zip the `shopify_theme/` folder contents (not the folder itself). The zip root must contain `layout/`, `sections/`, `snippets/`, `templates/`, etc.
   - In Shopify Admin → Online Store → Themes → Add theme → Upload zip.

2. Customize
   - Online Store → Themes → Customize
   - Home page: configure the two Featured Collection sections (e.g., New Arrivals, Best Sellers)
   - Header links can be swapped to use navigation menus if desired; current links point to expected collections.

3. Products/Collections
   - Collection URLs used:
     - /collections/all
     - /collections/new (adjust if your handle differs)
     - /collections/best-sellers (adjust handle)
     - /collections/journeys-x-leyos-collection (adjust handle)

4. Cart & Checkout
   - Uses Shopify’s native cart page and checkout (`name="checkout"` submit).
   - Product page uses the standard `form 'product'` with variant options. Add/Buy flows are fully native.

## Notes & Next Steps

- If your store uses different collection handles, update links in `sections/header.liquid` and featured section settings accordingly.
- To remove dependency on the external CSS, copy your CSS into `assets/theme.css` and update references.
- Consider adding more sections (e.g., category panels, secondary banners) to mirror all homepage elements.
- If you want an Ajax cart drawer matching your current UX, we can add a cart-drawer section and minimal JS using Shopify Ajax Cart API.

## Support

If anything looks off after upload, share screenshots/URLs and we can tweak the markup or move styles into the theme for fully local assets.

